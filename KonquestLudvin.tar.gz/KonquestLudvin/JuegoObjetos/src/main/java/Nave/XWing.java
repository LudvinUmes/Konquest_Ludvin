/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nave;

/**
 *
 * @author baquiax
 */
public class XWing extends Nave {
    
    public XWing() {
        //nombre, capacidad, velocidad, costoProducion
        super("X-Wing", 42, 1.25, 50);
    }
    
    
}
