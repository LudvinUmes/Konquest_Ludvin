/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nave;

/**
 *
 * @author baquiax
 */
public class MillenialFalcon extends Nave {
    
    public MillenialFalcon() {
        //nombre, capacidad, velocidad, costoProducion
        super("Millenial Falcon", 58, 1.5, 70);
    }
    
    
}
