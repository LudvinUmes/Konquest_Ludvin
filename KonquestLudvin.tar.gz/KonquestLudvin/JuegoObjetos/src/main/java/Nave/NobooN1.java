/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nave;

/**
 *
 * @author baquiax
 */
public class NobooN1 extends Nave {
    
    public NobooN1() {
        //nombre, capacidad, velocidad, costoProducion
        super("Noboo N-1", 25, 1, 40);
    }
    
    
}
