/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructor;

/**
 *
 * @author baquiax
 */
public class Arquitecto extends Constructor {

    public Arquitecto() {
        //nombre, tiempoConstruccion, precioCompra, precioVenta, naveConstruccion
        super("Arquitecto", 1, 250, 175, "Millenial Falcon");

    }

}
