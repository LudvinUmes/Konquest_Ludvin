/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructor;

/**
 *
 * @author baquiax
 */
public class Obrero extends Constructor {

    public Obrero() {
        //nombre, tiempoConstruccion, precioCompra, precioVenta, naveConstruccion
        super("Obrero", 3, 50, 40, "Naboo N-1");

    }

}
