/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guerreros;

/**
 *
 * @author baquiax
 */
public class Magma extends Guerrero {

    public Magma() {
        //Nombre, factorDeMuerte, espacioEnNave
        super("Magma", 1.75, 2);
    }

}
