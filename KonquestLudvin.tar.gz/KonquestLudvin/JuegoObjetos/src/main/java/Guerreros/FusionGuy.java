/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guerreros;

/**
 *
 * @author baquiax
 */
public class FusionGuy extends Guerrero {

    public FusionGuy() {
        //Nombre, factorDeMuerte, espacioEnNave
        super("Fusion Guy", 1.95, 4);
    }

}
