/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Guerreros;

/**
 *
 * @author baquiax
 */
public class Mole extends Guerrero {

    public Mole() {
        //Nombre, factorDeMuerte, espacioEnNave
        super("Mole", 1.5, 1);
    }

}
